--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Bluemoon";
--
-- Name: Bluemoon; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Bluemoon" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "Bluemoon" OWNER TO postgres;

\connect "Bluemoon"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hokhau; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hokhau (
    hokhauid integer NOT NULL,
    sothanhvien integer NOT NULL,
    sonha character varying(255),
    duong character varying(255),
    phuong character varying(255),
    quan character varying(255),
    ngaylamhokhau timestamp(6) without time zone,
    ngaythemnhankhau timestamp(6) without time zone,
    quanhevoichuho character varying(255),
    xemay integer,
    oto integer,
    dientich double precision,
    CONSTRAINT hokhau_sothanhvien_check CHECK ((sothanhvien > 0))
);


ALTER TABLE public.hokhau OWNER TO postgres;

--
-- Name: hokhau_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hokhau_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hokhau_id_seq OWNER TO postgres;

--
-- Name: hokhau_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hokhau_id_seq OWNED BY public.hokhau.hokhauid;


--
-- Name: khoanthu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.khoanthu (
    khoanthuid integer NOT NULL,
    ngaytao timestamp(6) without time zone,
    thoihan timestamp(6) without time zone,
    tenkhoanthu character varying(255) NOT NULL,
    ghichu character varying(255),
    tinhchat integer NOT NULL
);


ALTER TABLE public.khoanthu OWNER TO postgres;

--
-- Name: khoanthu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.khoanthu_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.khoanthu_id_seq OWNER TO postgres;

--
-- Name: khoanthu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.khoanthu_id_seq OWNED BY public.khoanthu.khoanthuid;


--
-- Name: lichsuthaydoihokhau; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lichsuthaydoihokhau (
    id integer NOT NULL,
    loaithaydoi integer,
    thoigian timestamp(6) without time zone,
    hokhauid integer,
    nhankhauid integer
);


ALTER TABLE public.lichsuthaydoihokhau OWNER TO postgres;

--
-- Name: lichsuthaydoihokhau_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lichsuthaydoihokhau_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lichsuthaydoihokhau_id_seq OWNER TO postgres;

--
-- Name: lichsuthaydoihokhau_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lichsuthaydoihokhau_id_seq OWNED BY public.lichsuthaydoihokhau.id;


--
-- Name: nhankhau; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nhankhau (
    nhankhauid integer NOT NULL,
    hoten character varying(255) NOT NULL,
    ngaysinh timestamp(6) without time zone,
    gioitinh boolean,
    dantoc character varying(255),
    tongiao character varying(255),
    cccd character varying(255),
    ngaycap timestamp(6) without time zone,
    noicap character varying(255),
    nghenghiep character varying(255),
    ghichu character varying(255),
    hokhauid integer
);


ALTER TABLE public.nhankhau OWNER TO postgres;

--
-- Name: nhankhau_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nhankhau_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nhankhau_id_seq OWNER TO postgres;

--
-- Name: nhankhau_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nhankhau_id_seq OWNED BY public.nhankhau.nhankhauid;


--
-- Name: nop_tien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nop_tien (
    id integer NOT NULL,
    ngaythu timestamp(6) without time zone,
    nguoinop character varying(255),
    tien real,
    khoanthuid integer,
    nhankhauid integer
);


ALTER TABLE public.nop_tien OWNER TO postgres;

--
-- Name: nop_tien_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nop_tien_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nop_tien_id_seq OWNER TO postgres;

--
-- Name: nop_tien_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nop_tien_id_seq OWNED BY public.nop_tien.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    roleid integer NOT NULL,
    rolename character varying(255) NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_role_id_seq OWNER TO postgres;

--
-- Name: roles_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_role_id_seq OWNED BY public.roles.roleid;


--
-- Name: tamtrutamvang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tamtrutamvang (
    id integer NOT NULL,
    trangthai character varying(255) NOT NULL,
    diachitamtrutamvang character varying(255),
    thoigian timestamp(6) without time zone,
    noidungdenghi character varying(255),
    nhankhauid integer
);


ALTER TABLE public.tamtrutamvang OWNER TO postgres;

--
-- Name: tamtrutamvang_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tamtrutamvang_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tamtrutamvang_id_seq OWNER TO postgres;

--
-- Name: tamtrutamvang_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tamtrutamvang_id_seq OWNED BY public.tamtrutamvang.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    roleid integer NOT NULL,
    enabled boolean NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: hokhau hokhauid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hokhau ALTER COLUMN hokhauid SET DEFAULT nextval('public.hokhau_id_seq'::regclass);


--
-- Name: khoanthu khoanthuid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.khoanthu ALTER COLUMN khoanthuid SET DEFAULT nextval('public.khoanthu_id_seq'::regclass);


--
-- Name: lichsuthaydoihokhau id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lichsuthaydoihokhau ALTER COLUMN id SET DEFAULT nextval('public.lichsuthaydoihokhau_id_seq'::regclass);


--
-- Name: nhankhau nhankhauid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nhankhau ALTER COLUMN nhankhauid SET DEFAULT nextval('public.nhankhau_id_seq'::regclass);


--
-- Name: nop_tien id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nop_tien ALTER COLUMN id SET DEFAULT nextval('public.nop_tien_id_seq'::regclass);


--
-- Name: roles roleid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN roleid SET DEFAULT nextval('public.roles_role_id_seq'::regclass);


--
-- Name: tamtrutamvang id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tamtrutamvang ALTER COLUMN id SET DEFAULT nextval('public.tamtrutamvang_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: hokhau; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hokhau (hokhauid, sothanhvien, sonha, duong, phuong, quan, ngaylamhokhau, ngaythemnhankhau, quanhevoichuho, xemay, oto, dientich) FROM stdin;
\.
COPY public.hokhau (hokhauid, sothanhvien, sonha, duong, phuong, quan, ngaylamhokhau, ngaythemnhankhau, quanhevoichuho, xemay, oto, dientich) FROM '$$PATH$$/4901.dat';

--
-- Data for Name: khoanthu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.khoanthu (khoanthuid, ngaytao, thoihan, tenkhoanthu, ghichu, tinhchat) FROM stdin;
\.
COPY public.khoanthu (khoanthuid, ngaytao, thoihan, tenkhoanthu, ghichu, tinhchat) FROM '$$PATH$$/4903.dat';

--
-- Data for Name: lichsuthaydoihokhau; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lichsuthaydoihokhau (id, loaithaydoi, thoigian, hokhauid, nhankhauid) FROM stdin;
\.
COPY public.lichsuthaydoihokhau (id, loaithaydoi, thoigian, hokhauid, nhankhauid) FROM '$$PATH$$/4905.dat';

--
-- Data for Name: nhankhau; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nhankhau (nhankhauid, hoten, ngaysinh, gioitinh, dantoc, tongiao, cccd, ngaycap, noicap, nghenghiep, ghichu, hokhauid) FROM stdin;
\.
COPY public.nhankhau (nhankhauid, hoten, ngaysinh, gioitinh, dantoc, tongiao, cccd, ngaycap, noicap, nghenghiep, ghichu, hokhauid) FROM '$$PATH$$/4907.dat';

--
-- Data for Name: nop_tien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nop_tien (id, ngaythu, nguoinop, tien, khoanthuid, nhankhauid) FROM stdin;
\.
COPY public.nop_tien (id, ngaythu, nguoinop, tien, khoanthuid, nhankhauid) FROM '$$PATH$$/4909.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (roleid, rolename) FROM stdin;
\.
COPY public.roles (roleid, rolename) FROM '$$PATH$$/4911.dat';

--
-- Data for Name: tamtrutamvang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tamtrutamvang (id, trangthai, diachitamtrutamvang, thoigian, noidungdenghi, nhankhauid) FROM stdin;
\.
COPY public.tamtrutamvang (id, trangthai, diachitamtrutamvang, thoigian, noidungdenghi, nhankhauid) FROM '$$PATH$$/4913.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, roleid, enabled) FROM stdin;
\.
COPY public.users (id, username, password, roleid, enabled) FROM '$$PATH$$/4915.dat';

--
-- Name: hokhau_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hokhau_id_seq', 1, true);


--
-- Name: khoanthu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.khoanthu_id_seq', 1, false);


--
-- Name: lichsuthaydoihokhau_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lichsuthaydoihokhau_id_seq', 1, false);


--
-- Name: nhankhau_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nhankhau_id_seq', 1, false);


--
-- Name: nop_tien_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nop_tien_id_seq', 1, false);


--
-- Name: roles_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_role_id_seq', 2, true);


--
-- Name: tamtrutamvang_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tamtrutamvang_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: hokhau hokhau_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hokhau
    ADD CONSTRAINT hokhau_pkey PRIMARY KEY (hokhauid);


--
-- Name: khoanthu khoanthu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.khoanthu
    ADD CONSTRAINT khoanthu_pkey PRIMARY KEY (khoanthuid);


--
-- Name: nhankhau nhankhau_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nhankhau
    ADD CONSTRAINT nhankhau_pkey PRIMARY KEY (nhankhauid);


--
-- Name: nop_tien nop_tien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nop_tien
    ADD CONSTRAINT nop_tien_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (roleid);


--
-- Name: roles roles_role_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_role_name_key UNIQUE (rolename);


--
-- Name: tamtrutamvang tamtrutamvang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tamtrutamvang
    ADD CONSTRAINT tamtrutamvang_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: nhankhau fk3pabuun6xe020unr6cct77td8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nhankhau
    ADD CONSTRAINT fk3pabuun6xe020unr6cct77td8 FOREIGN KEY (hokhauid) REFERENCES public.hokhau(hokhauid);


--
-- Name: tamtrutamvang fk5ms52xtx34fcj3g2s3l4rqnol; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tamtrutamvang
    ADD CONSTRAINT fk5ms52xtx34fcj3g2s3l4rqnol FOREIGN KEY (nhankhauid) REFERENCES public.nhankhau(nhankhauid);


--
-- Name: users fk_users_role; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_role FOREIGN KEY (roleid) REFERENCES public.roles(roleid);


--
-- Name: nop_tien fkdsm3jq9r2ewlgtkb509xi1g5y; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nop_tien
    ADD CONSTRAINT fkdsm3jq9r2ewlgtkb509xi1g5y FOREIGN KEY (nhankhauid) REFERENCES public.nhankhau(nhankhauid);


--
-- Name: lichsuthaydoihokhau fkkiccfqjmdloe33ku6o2hrgjd4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lichsuthaydoihokhau
    ADD CONSTRAINT fkkiccfqjmdloe33ku6o2hrgjd4 FOREIGN KEY (hokhauid) REFERENCES public.hokhau(hokhauid);


--
-- Name: lichsuthaydoihokhau fkmcnca1uu13clar4e9j5pr2831; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lichsuthaydoihokhau
    ADD CONSTRAINT fkmcnca1uu13clar4e9j5pr2831 FOREIGN KEY (nhankhauid) REFERENCES public.nhankhau(nhankhauid);


--
-- Name: nop_tien fktp5tcjhp59qu2wwl3squc7gw5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nop_tien
    ADD CONSTRAINT fktp5tcjhp59qu2wwl3squc7gw5 FOREIGN KEY (khoanthuid) REFERENCES public.khoanthu(khoanthuid);


--
-- PostgreSQL database dump complete
--

